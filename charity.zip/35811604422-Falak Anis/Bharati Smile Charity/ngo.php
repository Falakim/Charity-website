
<?php
echo "<body style='background-color:aliceblue;'>";
require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);

$query="select NgoId ,Ngo_Name from ngo";
$result=$conn->query($query);
if(!$result) die($conn->error);
$rows=$result->num_rows;

echo <<<GFG
<!doctype html>
<html>
<head>
<title>About </title>
<link rel="stylesheet" href="footer3.css">
<link rel="stylesheet" href="form3.css">

<style>
tr:nth-child(odd) {
  background-color: #e6f0f7;;
}
tr:nth-child(even) {
  background-color: white;;
}
.button3
{    background-color: #171c46;
  border: 1px solid grey;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin-right: 17px;
  cursor: pointer;
  border-radius: 16px;
}

  .button3:hover {
    background-color:#000e2b;;
  color:white
  }
  
  


</style>
</head>

<body> 
 

<br><br><br><br>
<br><br><br><br>


GFG;

echo "<center>";
echo "<h1 style='color:#192841;'>NGOs</h1>";
echo "<br><br>";
echo "<table style=' border-collapse: collapse;width:600px;'>";
	echo "<tr>";
	echo "<th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Ngo Id</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Ngo Name</th>";
	echo "</tr>";
for($i=0;$i<$rows;$i++)
{
$result->data_seek($i);
$row=$result->fetch_array(MYSQLI_ASSOC);

	echo "<tr>";
echo "<td style='text-align: left;padding: 8px;'>".$row['NgoId']."</td>";
echo "<td style='text-align: left;padding: 8px;'>".$row['Ngo_Name']."</td>";



	echo "</tr>";
	
}
echo "</table>";
echo "<br><br>";
echo "<a href=admindatabasenew.html><button class=button3 style=padding: 15px 43px;
font-size: large;border-radius: 30px;float: right;>Back</button></a>";
echo "</center>";



echo <<<GFG

   <br><br><br> 
<br><br><br> <br><br><br> <br><br><br> 
<footer>
    <p>&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>
		
	</footer>
</body>
</html>
GFG;

?>
