<?php
echo "<body style='background-color:aliceblue;'>";
require_once 'login1.php';
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
$mycat=$_POST['cat'];
$myqty=$_POST['qty'];
$myid=$_POST['collegeid'];
$q="CREATE Table cart(CollegeId varchar(20),Donation_Category varchar(20),Donation_Quantity int)";
$r= $conn->query($q);
	if (!$r) die($conn->error);
for($i=0;$i<sizeof($mycat);$i++)
{
	$query = "INSERT INTO  mycart(CollegeId,Donation_Category,Donation_Quantity) VALUES('$myid','$mycat[$i]','$myqty')";
	$result = $conn->query($query);
	if (!$result) die($conn->error);
	$q1= "INSERT INTO  cart VALUES('$myid','$mycat[$i]','$myqty')";
$r1= $conn->query($q1);
	if (!$r1) die($conn->error);

}



$collegeid=$_POST['collegeid'];
     
	$category= $_POST['cat'];
     	$qty=$_POST['qty'];
echo <<<GFG
<!doctype html>
<html>
<head>
<title>About </title>
<link rel="stylesheet" href="footer2.css">
<link rel="stylesheet" href="form.css">
<link rel="stylesheet" href="nav.css">
<style>
tr
{

background-color:white;
}
input
{
border:none;
}
.cartbutton1,.cartbutton2
{

 background-color:#192841;
  border: none;
  color: white;
  padding: 15px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
 
  border-radius: 16px;
}
.cartbutton1
{
padding:4px;
}
.cartbutton1:hover,.cartbutton2:hover {
  background-color: white;
  border:2px solid #192841;
  font-weight:bold;
  color:#192841;
}
</style>
</head>

<body> 
 
<div class="navbar">
    <a href="signin1.html"><button class="button">Donate</button></a>
    <a href="contact.html"><button class="button">Contact Us</button></a>
    <a href="gallery.html"><button class="button">Gallery</button></a>
    <a href="ngos.html"><button class="button">NGOs</button></a>
    <a href="about.html"><button class="button">About Us</button></a>
    <a href="index.html"><button class="button">Home</button></a>
    <div class ="logo-image">
    <img src="images/logo1.jpg" style="height:150px;width: 150px;">

  </div>
    </div>




GFG;
echo "<center>";
echo "<h1 style='color:#192841;'>Donation Cart </h1>";
echo "<br><br>";

	
echo "<table style=' border-collapse: collapse;
  width:600px;
  '>";
	echo "<tr>";
	echo"<th style='background-color:#192841;
color:white;text-align: left;
  padding: 8px;'>College Id</th><th style='background-color:#192841;
color:white;text-align: left;
  padding: 8px;'>Category</th><th style='background-color:#192841;
color:white;text-align: left;
  padding: 8px;'>Quantity</th><th style='background-color:#192841;
color:white;text-align: left;
  padding: 8px;'>Action</th></tr>";
	
	
	foreach($category as $item)echo "<tr><form method=post action=updatedcartview1.php><td style='text-align: left;
  padding: 8px;font-size:20px;'><input type=text name=collegeid id=collegeid readonly value=$collegeid></input></td><td  style='  text-align: left;
  padding: 8px;font-size:20px;'><input type=text name=category id=category readonly value=$item></input></td><td style='  text-align: left;
  padding: 8px;font-size:20px;'><input type=number name=quantity id=quantity value=$qty></input></td><td style='  text-align: left;
  padding: 8px;font-size:20px;'><input type=submit class=cartbutton1 value=Update style='width:7em;'></input></td></form></tr>";
echo"</table>";
	echo "<br><br>";
echo "<form method=post action=showdonation1.php>";

echo "<input type=text readonly name=collegeid id=collegid value=$collegeid hidden></input>";
echo "<input type=submit class=cartbutton2 value=Donate style='width:7em;'></input>";
echo "</form>";
	
echo "</center>";




echo <<<GFG

<section style="margin-top:300px;">
        
  <div class="row">
<div class="column left">
<h2>About Us</h2>
<p style="color:white">Bharati Smile Charity is a platform for the donators to donate for the needy children. Here we present a number of NGO's who are working for the well being of the underpriviledged students by providing materials like Clothes, Stationery, medicinal help etc. You can look up for upcoming charity drives taking place in the territory of Delhi.</p>
</div>
<div class="column middle">
<h2>Useful Links</h2>

<p style="padding-top: 5px;color:white""><a href="about.html">About Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="gallery.html">Gallery<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="ngos.html">NGOs<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="contact.html">Contact Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="signin1.html">Donate<i class="arrow right1"></a></i></p>
<hr>
</div>
<div class="column right">
<h2>Contact Us</h2>
<p style="color:white">Bharati vidyapeeth institute of computer</p><p style="color:white"> Application &Management</p><p style="color:white">
A-4,Paschim vihar</p><p style="color:white">
New Delhi , IND</p>
</div>
</div>

</section>

<footer>
<p style="padding-bottom:10px;font-size:small;">&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>

</footer>
</body>
</html>
GFG;
?>