<?php
$hn='localhost';
$un='mca';
$db='registration';
$pw='password';
?>