<?php

require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$adminid=$_POST['adminid'];
$password=$_POST['mypassword'];

$query1="SELECT * FROM Admin where AdminId='$adminid' AND Password='$password'";
$result1=$conn->query($query1);
if(!$result1) die($conn->error);
$rows=$result1->num_rows;
if($rows==0)
{
	
	
echo <<<GFG

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="login3.css">
    <link rel="stylesheet" href="form3.css">
    <title>Admin Page</title>
  </head>
  <body>

    <div class="signin-container">
      <form action = "signindatabase1.php" method="post">
        <h1 class = "heading1">Login Again</h1>
        <input type="text" name="adminid" id="adminid" placeholder="Admin Id">
        <input type="password" name="mypassword" id="mypassword" placeholder="Password">
        <br>
        <button type="submit">Submit</button>
      
      </form>
    </div>
  </body>
</html>

GFG;

}
else
{
	echo <<<GFG

<!doctype html>
<html>
<head>
<title>Donations</title>
<link rel="stylesheet" href="footer3.css">
<link rel="stylesheet" href="form3.css">
<style>
.img1
{
  -webkit-filter: drop-shadow(15px 15px 15px #222 );
  filter: drop-shadow(4px 4px 4px #222);

}
.img2
{
  float:left;
}
.row1
{
  clear:left;
}
</style>
</head>
<body>
<img src="images/admin1.jpeg" height=100px width=100px float=right class="img2">
<h1 style="padding-top:40px;">Welcome Admin</h1>
<div class="row1">
  <div class="column1 left">
  <a href="user.php"><img src="images/users.jpg" height=230px width=230px class="img1" title="Click here to see Users"></a><br>
  <h2 style="font-size: 30px;color: #1e2436;padding-top:30px;">Users</h2>
   
 
  </div>

  <div class="column1 middle">
  <a href="stock.php"><img src="images/stock.jpg" height=230px width=230px class="img1" title="Click here to see Stock"></a><br>
  <h2 style="font-size: 30px;color: #1e2436;padding-top:30px;">Stock</h2>
 
  </div>
 
  <div class="column1 right">
  <a href="ngo.php"><img src="images/ngo.jpg" height=230px width=230px class="img1" title="Click here to see Ngo's"></a><br>
  <h2 style="font-size: 30px;color: #1e2436;padding-top:30px;">NGOs</h2>
  
  </div>
</div>
     
	
<footer>
    <p>&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>
		
	</footer>
</body>
</html>
GFG;
	
}
$result1->close();
$conn->close();
?>









