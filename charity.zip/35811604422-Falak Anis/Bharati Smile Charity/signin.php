

<?php

require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$username=$_POST['uname'];
$password=$_POST['password'];

$contact=$_POST['c_num'];
$contactid=$_POST['c_id'];
$email=$_POST['email'];


$query2="INSERT INTO Users VALUES('$contactid','$username','$password','$contact','$email')";
$result2=$conn->query($query2);
if(!$result2) die($conn->error);


?>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="login.css">
    <link rel="stylesheet" href="form.css">
    <title>Sign In Page</title>
  </head>
  <body>

    <div class="signin-container">
      <form action = "signindatabase.php" method="post">
        <h1 class = "heading1">Sign in</h1>
        <input type="text" name="mycollegeid" id="mycollegeid" placeholder="College Id">
        <input type="password" name="mypassword" id="mypassword" placeholder="Password">
        <br>
        <button type="submit">Submit</button>
        <div class="statement text-align-center">
            <p>
                New user? <a href="signup.html">sign up</a>
            </p>
        </div>
      </form>
    </div>
  </body>
</html>