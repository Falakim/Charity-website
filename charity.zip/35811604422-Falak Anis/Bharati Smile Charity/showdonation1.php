
<?php
echo "<body style='background-color:aliceblue;'>";
require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$collegeid=$_POST['collegeid'];
$query="SELECT * FROM cart where CollegeId='$collegeid'";
$result=$conn->query($query);
if(!$result) die($conn->error);
$rows=$result->num_rows;

echo <<<GFG
<!doctype html>
<html>
<head>
<title>About </title>
<link rel="stylesheet" href="footer2.css">
<link rel="stylesheet" href="form.css">
<link rel="stylesheet" href="nav.css">
<style>
tr:nth-child(odd) {
  background-color: #e6f0f7;;
}
tr:nth-child(even) {
  background-color: white;;
}
</style>
</head>

<body> 
 
<div class="navbar">
    <a href="signin1.html"><button class="button">Donate</button></a>
    <a href="contact.html"><button class="button">Contact Us</button></a>
    <a href="gallery.html"><button class="button">Gallery</button></a>
    <a href="ngos.html"><button class="button">NGOs</button></a>
    <a href="about.html"><button class="button">About Us</button></a>
    <a href="index.html"><button class="button">Home</button></a>
    <div class ="logo-image">
    <img src="images/logo1.jpg" style="height:150px;width: 150px;">

  </div>
    </div>




GFG;
echo "<center>";
echo "<h1 style='color:#192841;'>Thanks For Donating !!</h1>";
echo "<br><br>";
echo "<table style=' border-collapse: collapse;
  width:600px;
  '>";
	echo "<tr>";
	echo "<th style='background-color:#192841;
color:white;text-align: left;
  padding: 8px;'>Category</th><th style='background-color:#192841;
color:white;  text-align: left;
  padding: 8px;'>Quantity</th>";
	echo "</tr>";
for($i=0;$i<$rows;$i++)
{
$result->data_seek($i);
$row=$result->fetch_array(MYSQLI_ASSOC);

	echo "<tr>";
     
	echo "<td style='  text-align: left;
  padding: 8px;'>".$row['Donation_Category']."</td><td style='  text-align: left;
  padding: 8px;'>".$row['Donation_Quantity']."</td>";
	echo "</tr>";
	
}
echo "</table>";

echo "</center>";

$qr= "Drop Table cart";
$rs= $conn->query($qr);

echo<<<GFG
<section style="margin-top:300px;">
        
  <div class="row">
<div class="column left">
<h2>About Us</h2>
<p style="color:white">Bharati Smile Charity is a platform for the donators to donate for the needy children. Here we present a number of NGO's who are working for the well being of the underpriviledged students by providing materials like Clothes, Stationery, medicinal help etc. You can look up for upcoming charity drives taking place in the territory of Delhi.</p>
</div>
<div class="column middle">
<h2>Useful Links</h2>

<p style="padding-top: 5px;color:white""><a href="about.html">About Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="gallery.html">Gallery<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="ngos.html">NGOs<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="contact.html">Contact Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;color:white""><a href="signin1.html">Donate<i class="arrow right1"></a></i></p>
<hr>
</div>
<div class="column right">
<h2>Contact Us</h2>
<p style="color:white">Bharati vidyapeeth institute of computer</p><p style="color:white"> Application &Management</p><p style="color:white">
A-4,Paschim vihar</p><p style="color:white">
New Delhi , IND</p>
</div>
</div>

</section>

<footer>
<p style="padding-bottom:10px;font-size:small;">&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>

</footer>
</body>
</html>
GFG;

?>
