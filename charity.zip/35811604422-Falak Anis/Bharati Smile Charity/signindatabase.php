<?php

require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$collegeid=$_POST['mycollegeid'];
$password=$_POST['mypassword'];

$query1="SELECT * FROM Users where CollegeId='$collegeid' AND Password='$password'";
$result1=$conn->query($query1);
if(!$result1) die($conn->error);
$rows=$result1->num_rows;

if($rows==0)
{
	
	
echo <<<GFG
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="login.css">
    <link rel="stylesheet" href="form.css">
    <title>Sign Up Page</title>
  </head>
  <body>
    <div class="signup-container">
      <form action="signin.php" method="post">
        <h1 class = "heading1">Create your account</h1>
      
            <div class="form-input">
                <label for="uname">User Name:</label>
                <input type="text"  name="uname" id="username" required >
                
                
                <label for="c_num">Contact No.:</label>
                <input type="text" name="c_num" id="c_num">
                <label for="c_id">College Id:</label>
                <input type="text" name="c_id" id="c_id">
                <label for="email">Email:</label>
                <input type="text" name="email" id="email">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
            
                <div class="justify-content-center">
                <button type="submit" class="btn">Submit</button>
                <div class="statement text-align-center">
                    <p>
                        Do you already have an account? <a href="signin1.html">sign in</a>
                    </p>
                    </div>
                </div>
            </div>
        </form>
    </div>
  </body>
</html>
GFG;
}
else
{
	echo <<<GFG

<!doctype html>
<html>
<head>
<title>Donations</title>
<link rel="stylesheet" href="footer1.css">
<link rel="stylesheet" href="form.css">
<link rel="stylesheet" href="nav.css">
</head>
<body>
  <nav class="navbar">
    <a href="signin1.html"><button class="button">Donate</button></a>
    <a href="contact.html"><button class="button">Contact Us</button></a>
    <a href="gallery.html"><button class="button">Gallery</button></a>
    <a href="home.html"><button class="button">NGOs</button></a>
    <a href="about.html"><button class="button">About Us</button></a>
    <a href="index.html"><button class="button">Home</button></a>
    <div class ="logo-image">
        <img src="images/logo1.jpg" style="height:150px;width: 150px;">
  
      </div>
  
  
  </nav> 



	<div class="container1" style="padding-bottom:200px;padding-right:100px;">
        <h2 style="padding-top:10px;font-size:32px;color:#444;text-align:left;padding-left:50px;">Donation Categories</h2>
        <p style="font-size:20px;color:#444; text-align:left;padding-left:50px;"><i>"Work For A Cause, Not For Applause.Live Life To Express Not To Impress"</i></p>
          <form method="post" action="donationform.php">
<label for="collegeid" hidden>CollegId</label>
<input type="text" readonly name="collegeid" id="collegid" value=$collegeid hidden></input>
<a href=""><button class="button1" style="padding: 15px 43px;
font-size: large;border-radius: 30px;float: right;">Donate Now</button></a>
</form>  

   </div>

    <div class="donationrow">
  <div class="donationcolumn left1">
    <h2 style="font-size:25px;color:#444;">Stationary</h2>
<img src="images/d1.jpg" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Giving a poor money keeps them poorer longer ..often forever. Give them knowledge instead.</p>

  </div>
  
  <div class="donationcolumn middle1">
    <h2 style="font-size:25px;color:#444;">Clothes</h2>

<img src="images/d2.jpg" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Give clothes. Make a fashion statement. Take a stand against poverty by donating your unwanted clothes.</p>
  
  </div>
 
  <div class="donationcolumn right2">
    <h2 style="font-size:25px;color:#444;">Medicine</h2>
<img src="images/d3.png" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Stop the disease, stop the illness make a difference donate medicine</p>

      </div>
</div>
<br>
 <div class="donationrow">
  <div class="donationcolumn left1">
    <h2 style="font-size:25px;color:#444;">Electronic Gadget</h2>
<img src="images/d4.png" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Don’t chuck that smartphone or PC that you think is past its prime. Donate it to a group that would place it in a pair of needy little hands.</p>

  </div>
  
  <div class="donationcolumn middle1">
    <h2 style="font-size:25px;color:#444;">Food</h2>
<img src="images/d5.jpg" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Togeather we can solve hunger.
Food For The Poor is one of the best charities you can opt for. Go on feed the hungry</p>
  
  </div>
 
  <div class="donationcolumn right2">
    <h2 style="font-size:25px;color:#444;">Miscellaneous</h2>
<img src="images/d6.jpg" height=130px>
<hr>
<p style="font-size:20px;color:#444;">Donate what u want we are here for u.Choose some of your old toys that are in good condition and donate them to charity.</p>

</form>
      </div>
</div>
<br>

<section>
        
<div class="row">
<div class="column left">
<h2>About Us</h2>
<p>Bharati Smile Charity is a platform for the donators to donate for the needy children. Here we present a number of NGO's who are working for the well being of the underpriviledged students by providing materials like Clothes, Stationery, medicinal help etc. You can look up for upcoming charity drives taking place in the territory of Delhi.</p>
</div>
<div class="column middle">
<h2>Useful Links</h2>
<p style="padding-top: 5px;"><a href="about.html">About Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;"><a href="gallery.html">Gallery<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;"><a href="ngos.html">NGOs<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;"><a href="contact.html">Contact Us<i class="arrow right1"></a></i></p>
<hr>
<p style="padding-top: 1px;"><a href="signin1.html">Donate<i class="arrow right1"></a></i></p>
<hr>
</div>
<div class="column right">
<h2>Contact Us</h2>
<p>Bharati vidyapeeth institute of computer</p><p> Application &Management</p><p>
A-4,Paschim vihar</p><p>
New Delhi , IND</p>
</div>
</div>

</section>

<footer>
<p style="padding-bottom:10px;font-size:small;">&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>

</footer>
</body>
</html>
GFG;
	
}
$result1->close();
$conn->close();
?>









