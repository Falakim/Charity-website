
<?php
echo "<body style='background-color:aliceblue;'>";
require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);

$query=" SELECT u.CollegeId,u.UserName,u.Contact,u.Email,c.DonationId,c.Donation_Category,c.Donation_Quantity FROM users u,mycart c where u.CollegeId=c.CollegeId;";
$result=$conn->query($query);
if(!$result) die($conn->error);
$rows=$result->num_rows;

echo <<<GFG
<!doctype html>
<html>
<head>
<title>About </title>
<link rel="stylesheet" href="footer3.css">
<link rel="stylesheet" href="form3.css">


<style>
tr
{

background-color:white;
}
input
{
border:none;
}
.cartbutton1,.cartbutton2
{

 background-color:#192841;
  border: none;
  color: white;
  padding: 15px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
 
  border-radius: 16px;
}
.cartbutton1
{
padding:4px;
}
.cartbutton1:hover,.cartbutton2:hover {
  background-color: white;
  border:2px solid #192841;
  font-weight:bold;
  color:#192841;
}
.button3
{    background-color: #171c46;
  border: 1px solid grey;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin-right: 17px;
  cursor: pointer;
  border-radius: 16px;
}

  .button3:hover {
    background-color:#000e2b;;
  color:white
  }
  
  
</style>
</head>

<body> 


<br><br><br><br>
<br><br><br><br>

GFG;

echo "<center>";
echo "<h1 style='color:#192841;'>USERS DATA</h1>";
echo "<br><br>";
echo "<table style=' border-collapse: collapse;width:600px;'>";
	echo "<tr>";
	echo "<th style='background-color:#192841;color:white;text-align:left;padding:8px;'>DonationId</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>CollegeId</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>UserName</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Contact</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Email</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Donation_Category</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Donation_Quantity</th><th style='background-color:#192841;color:white;text-align: left;padding: 8px;'>Action</th>";
	echo "</tr>";
for($i=0;$i<$rows;$i++)
{
$result->data_seek($i);
$row=$result->fetch_array(MYSQLI_ASSOC);

	echo "<tr><form method=post action=del.php>";
     echo "<td style='text-align:left;padding: 8px;'><input type=number readonly name=donationid id=donationid value=".$row['DonationId']."></input></td>";
	echo "<td style='text-align:left;padding: 8px;'>".$row['CollegeId']."</td>";
echo "<td style='text-align: left;padding: 8px;'>".$row['UserName']."</td>";


echo "<td style='text-align: left;padding: 8px;'>".$row['Contact']."</td>";
echo "<td style='text-align: left;padding: 8px;'>".$row['Email']."</td>";
	

echo "<td style='text-align: left;padding: 8px;'><input type=text readonly name=donationcat id=donationcat value=".$row['Donation_Category']."></input></td>";

echo "<td style='text-align: left;padding: 8px;'><input type=number readonly name=donationqty id=donationqty value=".$row['Donation_Quantity']."></input></td>";
echo "<td style='text-align: left;padding: 8px;'><input type=submit class=cartbutton1 value=delete style='width:7em;'></input></td></form>";
	echo "</tr>";
	
}
echo "</table>";
echo "<br><br>";
echo "<a href=admindatabasenew.html><button class=button3 style=padding: 15px 43px;
font-size: large;border-radius: 30px;float: right;>Back</button></a>";
echo "</center>";



echo <<<GFG

   <br><br><br> 
<br><br><br> <br><br><br> <br><br><br> 
<footer>
    <p>&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>
		
	</footer>
</body>
</html>
GFG;

?>
