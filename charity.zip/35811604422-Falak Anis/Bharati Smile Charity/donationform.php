<?php
require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$collegeid=$_POST['collegeid'];

echo <<<GFG


<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="login.css">
    <link rel="stylesheet" href="form1.css">

    <title>Donation Form</title>
  </head>
  <body>


    <div class="signup-container">
      <form action="show.php" method="post">
        <h1 class = "heading1">Donation Form</h1>
      
            <div class="form-input">
               <label for="collegeid">College Id</label>
		<input type="text" name="collegeid" id="collegeid" readonly value=$collegeid></input>

                   <label for="qty">Donation Qty</label><br>
		<input type="number" name="qty" id="qty" required></input>
		<fieldset style="border: 1px solid  rgb(139, 205, 159); width: 100%;
    padding: 0.5em;
    margin: 1em 0;
    border-radius: 5px;"><legend>Donation Category</legend>
    
<input type="checkbox" name="cat[]" value="Books" id="cat">Book</input><br>
<input type="checkbox" name="cat[]" value="Clothes" id="cat">Clothes</input><br>
<input type="checkbox" name="cat[]" value="Medicine" id="cat">Medicine</input><br>
<input type="checkbox" name="cat[]" value="Electronic Gadget" id="cat">Electronic Gadget</input><br>
<input type="checkbox" name="cat[]" value="Food" id="cat">Food</input><br>
<input type="checkbox" name="cat[]" value="Miscellaneous" id="cat">Miscellaneous</input><br>
  

</fieldset>

            
                <div class="justify-content-center">
                <button type="submit" class="btn">Submit</button>
              
                </div>
            </div>
        </form>
    </div>

  </body>
</html>

GFG;
?>