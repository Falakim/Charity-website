<?php

require_once 'login1.php';
$conn=new mysqli($hn,$un,$pw,$db);
if($conn->connect_error) die($conn->connect_error);
$adminid=$_POST['adminid'];
$password=$_POST['mypassword'];

$query1="SELECT * FROM Admin where AdminId='$adminid' AND Password='$password'";
$result1=$conn->query($query1);
if(!$result1) die($conn->error);
$rows=$result1->num_rows;
if($rows==0)
{
	
	
echo <<<GFG

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="login3.css">
    <link rel="stylesheet" href="form3.css">
    <title>Admin Page</title>
  </head>
  <body>

    <div class="signin-container">
      <form action = "signindatabase1.php" method="post">
        <h1 class = "heading1">Login Again</h1>
        <input type="text" name="adminid" id="adminid" placeholder="Admin Id">
        <input type="password" name="mypassword" id="mypassword" placeholder="Password">
        <br>
        <button type="submit">Submit</button>
      
      </form>
    </div>
  </body>
</html>

GFG;

}
else
{
	echo <<<GFG

<!doctype html>
<html>
<head>
<title>Donations</title>
<link rel="stylesheet" href="footer1.css">
<link rel="stylesheet" href="form.css">
<link rel="stylesheet" href="nav.css">
</head>
<body>
  <nav class="navbar">
    <a href="ngo.php"><button class="button">NGOs</button></a>
   
    <a href="stock.php"><button class="button">Stock</button></a>
 <a href="user.php"><button class="button">Users</button></a>
  
  
  </nav> 
  <div class="row1" style="background-color:aliceblue;">
  <div class="column1 left">
   <img src="images/n1.jpg" height=250px width=250px>
 <h2>Deepalaya</h2>
<a href="https://www.deepalaya.org/"><u>Click here to visit Website</u></a>
<p>Deepalaya is a New Delhi based organization with projects being implemented across north India. The organization is working dedicatedly towards improving the lives of children in vulnerable conditions.</p>
 
    </div>
  <div class="column1 middle">
   <img src="images/n2.jpg" height=250px width=250px>
 <h2>Smile Foundation NGO</h2>
<a href="https://www.smilefoundationindia.org/education/#"><u>Click here to visit Website</u></a>
<p>Established in 2002, Smile Foundation is an Indian development organization, directly benefitting over 15 lakh children and their families every year.</p>    </div>
  <div class="column1 right">
   <img src="images/n2.png" height=250px width=250px>
 <h2>Amani Children's Home</h2>
<a href="https://childrenofamani.org/about/"><u>Click here to visit Website</u></a>
<p>Amani Children’s Home supports underserved children in Mto wa Mbu, Tanzania in their academic endeavors, emotional development and physical wellbeing, through full-time residential care.</p>
  </div>
<br>
<br>

<br>
<br>
<br>
<br>


	
<footer>
    <p>&copy;All Rights Reserved | Designed and Developed by Bharati Smile Charity.</p>
		
	</footer>
</body>
</html>
GFG;
	
}
$result1->close();
$conn->close();
?>









